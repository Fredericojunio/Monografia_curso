# Link-Oportuno: fase 1 (registo, login e confirmacao)

## Como testar no computador (XAMPP)
1. Copie a pasta `link-oportuno` para `C:\xampp\htdocs\`.
2. Ligue o **Apache** e o **MySQL** no painel do XAMPP.
3. Abra `http://localhost/phpmyadmin`, va a **Importar** e escolha `sql/link_oportuno.sql`.
4. Se a pasta tiver outro nome ou local, ajuste `BASE_URL` em `src/config.php`.
5. Abra `http://localhost/link-oportuno/public/`.

## Como funciona o codigo de confirmacao (modo desenvolvimento)
O codigo NAO e enviado por e-mail. Fica numa linha de
`storage/logs/codigos.log` (data | e-mail | codigo). Abra o ficheiro,
copie o codigo e escreva-o na pagina "Confirmar e-mail".
Quando houver servico de e-mail, mude `AMBIENTE` para `producao`
em `src/config.php` e implemente o envio SMTP em `enviar_codigo()`
(ficheiro `src/codigos.php`).

## Criar um administrador
No terminal, dentro da pasta do projeto:
    php criar-admin.php "Nome" email@exemplo.com SenhaForte123

## O que ja funciona
- Registo de jovem e de empresa (NUIT unico, bloqueios de contas banidas)
- Confirmacao do e-mail com codigo de 6 digitos (10 min, 5 tentativas, reenvio)
- Login por perfil (jovem, empresa, admin) com sessao segura
- Protecao CSRF, senhas com hash, consultas preparadas (PDO)

## Proximas fases
2. Empresa: perfil e publicacoes   3. Feed, seguir e comentar
4. Documentos e candidaturas       5. Selo e painel do administrador
6. Denuncias, avisos e banimento   7. Testes e acabamento

## Ver o app sem computador (GitHub Codespaces)
1. No GitHub, crie um repositorio (pode ser privado).
2. Va a **Add file > Upload files** e carregue o ficheiro ZIP do projeto.
3. Abra **Code > Codespaces > Create codespace on main**.
4. No terminal do Codespaces:
       unzip link-oportuno-fase1.zip
       cd link-oportuno
       bash .devcontainer/setup.sh
       bash .devcontainer/iniciar.sh
5. Abra o separador **PORTAS**, porta 8000, e toque no endereco para ver o app.
6. O codigo de confirmacao esta em `storage/logs/codigos.log`
   (no terminal: `cat storage/logs/codigos.log`).
7. Erros do PHP: `cat /tmp/link-php.log`
8. Criar administrador: `/usr/bin/php criar-admin.php "Nome" email senha`
   (apos exportar: `export LINK_DB_USER=link LINK_DB_PASS=link`)

Se mais tarde guardar a pasta `link-oportuno` na raiz do repositorio,
o Codespaces executa tudo sozinho ao abrir (ficheiro `.devcontainer`).
