#!/usr/bin/env bash
# Instala PHP e MariaDB e importa a base de dados (corre uma vez)
set -e
cd "$(dirname "$0")/.."

sudo apt-get update -y
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y php-cli php-mysql php-mbstring mariadb-server unzip

sudo service mariadb start || sudo service mysql start
for i in $(seq 1 30); do
  sudo mariadb -e "SELECT 1" >/dev/null 2>&1 && break
  sleep 1
done

if ! sudo mariadb -e "USE link_oportuno" 2>/dev/null; then
  sudo mariadb < sql/link_oportuno.sql
fi

sudo mariadb -e "CREATE USER IF NOT EXISTS 'link'@'localhost' IDENTIFIED BY 'link'; GRANT ALL PRIVILEGES ON link_oportuno.* TO 'link'@'localhost'; FLUSH PRIVILEGES;"
mkdir -p storage/logs
echo "Preparado. Agora execute: bash .devcontainer/iniciar.sh"
