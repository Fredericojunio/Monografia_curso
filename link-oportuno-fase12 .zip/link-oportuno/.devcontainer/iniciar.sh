#!/usr/bin/env bash
# Liga a base de dados e o servidor PHP (porta 8000)
cd "$(dirname "$0")/.."

sudo service mariadb start >/dev/null 2>&1 || sudo service mysql start >/dev/null 2>&1
pkill -f "php -S 0.0.0.0:8000" 2>/dev/null || true

export LINK_BASE_URL="" LINK_DB_USER=link LINK_DB_PASS=link
# /usr/bin/php: o PHP instalado pelo setup.sh (inclui pdo_mysql)
nohup /usr/bin/php -d display_errors=1 -d error_reporting=E_ALL \
  -S 0.0.0.0:8000 -t public > /tmp/link-php.log 2>&1 &
sleep 1
echo "App a correr na porta 8000. Abra o separador PORTAS e toque no endereco."
echo "Erros do PHP: cat /tmp/link-php.log"
