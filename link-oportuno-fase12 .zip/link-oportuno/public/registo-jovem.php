<?php
require __DIR__ . '/../src/bootstrap.php';

if ($atual = utilizador_atual()) {
    redirecionar(pagina_inicial($atual['tipo']));
}

$erros = [];
$provincias = db()->query('SELECT id, nome FROM provincia ORDER BY nome')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $nome  = trim($_POST['nome'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $tel   = trim($_POST['telefone'] ?? '');
    $prov  = (int) ($_POST['provincia_id'] ?? 0);
    $senha = $_POST['senha'] ?? '';
    $senha2 = $_POST['senha2'] ?? '';

    if (mb_strlen($nome) < 3)                          $erros[] = 'Escreva o seu nome completo.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))    $erros[] = 'Escreva um e-mail válido.';
    if (!telefone_valido($tel))                        $erros[] = 'Telefone inválido.';
    if (!in_array($prov, array_column($provincias, 'id'))) $erros[] = 'Escolha a sua província.';
    if (strlen($senha) < 8)                            $erros[] = 'A palavra-passe deve ter pelo menos 8 caracteres.';
    if ($senha !== $senha2)                            $erros[] = 'As palavras-passe não coincidem.';
    if (!isset($_POST['termos']))                      $erros[] = 'Aceite os termos de uso e a política de privacidade.';

    if (!$erros && bloqueado('email', $email)) {
        $erros[] = 'Não é possível criar uma conta com este e-mail.';
    }
    if (!$erros) {
        $st = db()->prepare('SELECT 1 FROM utilizador WHERE email = ?');
        $st->execute([$email]);
        if ($st->fetchColumn()) {
            $erros[] = 'Este e-mail já está registado.';
        }
    }

    if (!$erros) {
        $pdo = db();
        try {
            $pdo->beginTransaction();
            $pdo->prepare(
                "INSERT INTO utilizador (nome, email, telefone, senha_hash, tipo, estado)
                 VALUES (?, ?, ?, ?, 'jovem', 'pendente')"
            )->execute([$nome, $email, $tel ?: null, password_hash($senha, PASSWORD_DEFAULT)]);
            $uid = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO jovem (utilizador_id, provincia_id) VALUES (?, ?)')
                ->execute([$uid, $prov]);
            $pdo->commit();

            iniciar_confirmacao($uid, $email);
            redirecionar('/confirmar-email.php');
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log($ex->getMessage());
            $erros[] = 'Não foi possível criar a conta. Tente novamente.';
        }
    }
}

$titulo = 'Registo de jovem';
require __DIR__ . '/../src/templates/header.php';
?>
<h1>Criar conta de jovem</h1>

<?php foreach ($erros as $erro): ?>
  <div class="aviso aviso-erro"><?= e($erro) ?></div>
<?php endforeach; ?>

<form method="post" class="cartao" novalidate>
  <?= csrf_campo() ?>

  <label>Nome completo
    <input type="text" name="nome" value="<?= antigo('nome') ?>" required>
  </label>
  <label>E-mail
    <input type="email" name="email" value="<?= antigo('email') ?>" required>
  </label>
  <label>Telefone (opcional)
    <input type="tel" name="telefone" value="<?= antigo('telefone') ?>" placeholder="+258 8X XXX XXXX">
  </label>
  <label>Província
    <select name="provincia_id" required>
      <option value="">Escolher</option>
      <?php foreach ($provincias as $p): ?>
        <option value="<?= (int) $p['id'] ?>" <?= (int) ($_POST['provincia_id'] ?? 0) === (int) $p['id'] ? 'selected' : '' ?>>
          <?= e($p['nome']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Palavra-passe
    <input type="password" name="senha" placeholder="Mínimo 8 caracteres" required>
  </label>
  <label>Repetir palavra-passe
    <input type="password" name="senha2" required>
  </label>
  <label class="check">
    <input type="checkbox" name="termos" <?= isset($_POST['termos']) ? 'checked' : '' ?>>
    <span>Aceito os termos de uso e a política de privacidade.</span>
  </label>
  <div class="info">Vamos enviar um código de confirmação para o seu e-mail.</div>
  <button type="submit" class="botao">Criar conta</button>
</form>

<p class="centro">Já tem conta? <a href="<?= e(url('/login.php')) ?>">Entrar</a></p>
<?php require __DIR__ . '/../src/templates/footer.php'; ?>
