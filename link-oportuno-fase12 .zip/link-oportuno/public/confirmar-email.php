<?php
require __DIR__ . '/../src/bootstrap.php';

$uid = (int) ($_SESSION['confirmar_id'] ?? 0);
if ($uid === 0) {
    redirecionar('/login.php');
}

$st = db()->prepare('SELECT id, nome, email, tipo, estado FROM utilizador WHERE id = ?');
$st->execute([$uid]);
$utilizador = $st->fetch();
if (!$utilizador) {
    unset($_SESSION['confirmar_id']);
    redirecionar('/login.php');
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = $_POST['acao'] ?? 'confirmar';

    if ($acao === 'reenviar') {
        $espera = REENVIO_SEGUNDOS - (time() - (int) ($_SESSION['ultimo_envio'] ?? 0));
        if ($espera > 0) {
            $erro = "Aguarde $espera segundos para pedir um novo código.";
        } else {
            iniciar_confirmacao($uid, $utilizador['email']);
            flash('ok', 'Enviámos um novo código.');
            redirecionar('/confirmar-email.php');
        }
    } else {
        $codigo = preg_replace('/\D/', '', $_POST['codigo'] ?? '');
        $tentativas = (int) ($_SESSION['tentativas_codigo'] ?? 0);

        if ($tentativas >= MAX_TENTATIVAS) {
            $erro = 'Demasiadas tentativas. Peça um novo código.';
        } elseif (strlen($codigo) !== 6) {
            $erro = 'Escreva os 6 dígitos do código.';
        } elseif (verificar_codigo($uid, $codigo)) {
            entrar($utilizador);
            flash('ok', 'E-mail confirmado. Bem-vindo ao Link-Oportuno!');
            redirecionar(pagina_inicial($utilizador['tipo']));
        } else {
            $_SESSION['tentativas_codigo'] = $tentativas + 1;
            $erro = 'Código incorreto ou expirado.';
        }
    }
}

$titulo = 'Confirmar e-mail';
require __DIR__ . '/../src/templates/header.php';
?>
<h1>Confirmar e-mail</h1>
<p>Enviámos um código de 6 dígitos para <strong><?= e(mascarar_email($utilizador['email'])) ?></strong>.
   O código expira em <?= (int) CODIGO_VALIDADE_MIN ?> minutos.</p>

<?php if (AMBIENTE === 'desenvolvimento'): ?>
  <div class="info">Modo de desenvolvimento: o código está no ficheiro <code>storage/logs/codigos.log</code>.</div>
<?php endif; ?>

<?php if ($erro): ?>
  <div class="aviso aviso-erro"><?= e($erro) ?></div>
<?php endif; ?>

<form method="post" class="cartao">
  <?= csrf_campo() ?>
  <input type="hidden" name="acao" value="confirmar">
  <label>Código
    <input type="text" name="codigo" inputmode="numeric" maxlength="6" autocomplete="one-time-code" class="codigo" required>
  </label>
  <button type="submit" class="botao">Confirmar</button>
</form>

<form method="post" class="centro">
  <?= csrf_campo() ?>
  <input type="hidden" name="acao" value="reenviar">
  <button type="submit" class="link">Reenviar código</button>
</form>
<p class="centro"><a href="<?= e(url('/logout.php')) ?>">Cancelar</a></p>
<?php require __DIR__ . '/../src/templates/footer.php'; ?>
