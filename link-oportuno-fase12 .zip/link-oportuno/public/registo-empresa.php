<?php
require __DIR__ . '/../src/bootstrap.php';

if ($atual = utilizador_atual()) {
    redirecionar(pagina_inicial($atual['tipo']));
}

$erros = [];
$provincias = db()->query('SELECT id, nome FROM provincia ORDER BY nome')->fetchAll();
$areas      = db()->query('SELECT id, nome FROM area_atuacao ORDER BY nome')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $nome  = trim($_POST['nome'] ?? '');
    $nuit  = preg_replace('/\s+/', '', $_POST['nuit'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $tel   = trim($_POST['telefone'] ?? '');
    $prov  = (int) ($_POST['provincia_id'] ?? 0);
    $area  = (int) ($_POST['area_id'] ?? 0);
    $senha = $_POST['senha'] ?? '';

    if (mb_strlen($nome) < 2)                          $erros[] = 'Escreva o nome da empresa.';
    if (!nuit_valido($nuit))                           $erros[] = 'O NUIT deve ter 9 dígitos.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))    $erros[] = 'Escreva um e-mail válido.';
    if (!telefone_valido($tel))                        $erros[] = 'Telefone inválido.';
    if (!in_array($prov, array_column($provincias, 'id'))) $erros[] = 'Escolha a província.';
    if (!in_array($area, array_column($areas, 'id')))      $erros[] = 'Escolha a área de atuação.';
    if (strlen($senha) < 8)                            $erros[] = 'A palavra-passe deve ter pelo menos 8 caracteres.';
    if (!isset($_POST['termos']))                      $erros[] = 'Aceite os termos de uso e a política de privacidade.';

    if (!$erros && (bloqueado('email', $email) || bloqueado('nuit', $nuit))) {
        $erros[] = 'Não é possível criar uma conta com estes dados.';
    }
    if (!$erros) {
        $st = db()->prepare('SELECT 1 FROM utilizador WHERE email = ?');
        $st->execute([$email]);
        if ($st->fetchColumn()) {
            $erros[] = 'Este e-mail já está registado.';
        }
        $st = db()->prepare('SELECT 1 FROM empresa WHERE nuit = ?');
        $st->execute([$nuit]);
        if ($st->fetchColumn()) {
            $erros[] = 'Já existe uma conta com este NUIT.';
        }
    }

    if (!$erros) {
        $pdo = db();
        try {
            $pdo->beginTransaction();
            $pdo->prepare(
                "INSERT INTO utilizador (nome, email, telefone, senha_hash, tipo, estado)
                 VALUES (?, ?, ?, ?, 'empresa', 'pendente')"
            )->execute([$nome, $email, $tel ?: null, password_hash($senha, PASSWORD_DEFAULT)]);
            $uid = (int) $pdo->lastInsertId();
            $pdo->prepare(
                'INSERT INTO empresa (utilizador_id, nome, nuit, provincia_id, area_id)
                 VALUES (?, ?, ?, ?, ?)'
            )->execute([$uid, $nome, $nuit, $prov, $area]);
            $pdo->commit();

            iniciar_confirmacao($uid, $email);
            redirecionar('/confirmar-email.php');
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log($ex->getMessage());
            $erros[] = 'Não foi possível criar a conta. Tente novamente.';
        }
    }
}

$titulo = 'Registo da empresa';
require __DIR__ . '/../src/templates/header.php';
?>
<h1>Registo da empresa</h1>
<ol class="passos">
  <li class="ativo">1 Dados</li><li>2 Confirmar e-mail</li><li>3 Selo (opcional)</li>
</ol>

<?php foreach ($erros as $erro): ?>
  <div class="aviso aviso-erro"><?= e($erro) ?></div>
<?php endforeach; ?>

<form method="post" class="cartao" novalidate>
  <?= csrf_campo() ?>

  <label>Nome da empresa
    <input type="text" name="nome" value="<?= antigo('nome') ?>" placeholder="Ex.: Tech Moz, Lda" required>
  </label>
  <label>NUIT
    <input type="text" name="nuit" value="<?= antigo('nuit') ?>" inputmode="numeric" maxlength="9" placeholder="9 dígitos" required>
  </label>
  <label>E-mail da empresa
    <input type="email" name="email" value="<?= antigo('email') ?>" placeholder="contacto@empresa.co.mz" required>
  </label>
  <label>Telefone
    <input type="tel" name="telefone" value="<?= antigo('telefone') ?>" placeholder="+258 8X XXX XXXX">
  </label>
  <div class="duas-colunas">
    <label>Província
      <select name="provincia_id" required>
        <option value="">Escolher</option>
        <?php foreach ($provincias as $p): ?>
          <option value="<?= (int) $p['id'] ?>" <?= (int) ($_POST['provincia_id'] ?? 0) === (int) $p['id'] ? 'selected' : '' ?>>
            <?= e($p['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Área de atuação
      <select name="area_id" required>
        <option value="">Escolher</option>
        <?php foreach ($areas as $a): ?>
          <option value="<?= (int) $a['id'] ?>" <?= (int) ($_POST['area_id'] ?? 0) === (int) $a['id'] ? 'selected' : '' ?>>
            <?= e($a['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </label>
  </div>
  <label>Palavra-passe
    <input type="password" name="senha" placeholder="Mínimo 8 caracteres" required>
  </label>
  <label class="check">
    <input type="checkbox" name="termos" <?= isset($_POST['termos']) ? 'checked' : '' ?>>
    <span>Aceito os termos de uso e a política de privacidade.</span>
  </label>
  <div class="info">Vamos enviar um código de confirmação para o e-mail da empresa.</div>
  <button type="submit" class="botao">Criar conta</button>
</form>

<p class="centro">Já tem conta? <a href="<?= e(url('/login.php')) ?>">Entrar</a></p>
<?php require __DIR__ . '/../src/templates/footer.php'; ?>
