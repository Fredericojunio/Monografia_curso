<?php
require __DIR__ . '/../../src/bootstrap.php';
$u = exigir_perfil('admin');
$titulo = 'Administração';
require __DIR__ . '/../../src/templates/header.php';
?>
<h1>Administração SILAS</h1>
<p>Olá, <?= e($u['nome']) ?>.</p>
<div class="info">Em construção: pedidos de selo, denúncias e medidas (próximas fases).</div>
<?php require __DIR__ . '/../../src/templates/footer.php'; ?>
