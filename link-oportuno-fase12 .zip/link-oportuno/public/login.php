<?php
require __DIR__ . '/../src/bootstrap.php';

if ($atual = utilizador_atual()) {
    redirecionar(pagina_inicial($atual['tipo']));
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $tentativas = (int) ($_SESSION['tentativas_login'] ?? 0);
    $email = strtolower(trim($_POST['email'] ?? ''));
    $senha = $_POST['senha'] ?? '';

    if ($tentativas >= MAX_TENTATIVAS) {
        $erro = 'Demasiadas tentativas. Feche o navegador e tente mais tarde.';
    } else {
        $st = db()->prepare('SELECT id, nome, email, senha_hash, tipo, estado FROM utilizador WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();

        if (!$u || !password_verify($senha, $u['senha_hash'])) {
            $_SESSION['tentativas_login'] = $tentativas + 1;
            $erro = 'E-mail ou palavra-passe incorretos.';
        } elseif ($u['estado'] === 'pendente') {
            iniciar_confirmacao((int) $u['id'], $u['email']);
            redirecionar('/confirmar-email.php');
        } elseif ($u['estado'] === 'suspenso') {
            $erro = 'A sua conta está suspensa. Pode contestar junto da SILAS.';
        } elseif ($u['estado'] === 'banido') {
            $erro = 'Esta conta foi encerrada.';
        } else {
            entrar($u);
            redirecionar(pagina_inicial($u['tipo']));
        }
    }
}

$titulo = 'Entrar';
require __DIR__ . '/../src/templates/header.php';
?>
<h1>Entrar</h1>

<?php if ($erro): ?>
  <div class="aviso aviso-erro"><?= e($erro) ?></div>
<?php endif; ?>

<form method="post" class="cartao">
  <?= csrf_campo() ?>
  <label>E-mail
    <input type="email" name="email" value="<?= antigo('email') ?>" required>
  </label>
  <label>Palavra-passe
    <input type="password" name="senha" required>
  </label>
  <button type="submit" class="botao">Entrar</button>
</form>

<p class="centro">Ainda não tem conta?</p>
<p class="centro">
  <a href="<?= e(url('/registo-jovem.php')) ?>">Sou jovem</a> &middot;
  <a href="<?= e(url('/registo-empresa.php')) ?>">Sou empresa</a>
</p>
<?php require __DIR__ . '/../src/templates/footer.php'; ?>
