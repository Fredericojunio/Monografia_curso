<?php
require __DIR__ . '/../src/bootstrap.php';
sair();
header('Location: ' . url('/login.php'));
exit;
