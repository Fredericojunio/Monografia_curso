<?php
require __DIR__ . '/../../src/bootstrap.php';
$u = exigir_perfil('empresa');
$titulo = 'Painel da empresa';
require __DIR__ . '/../../src/templates/header.php';
?>
<h1>Painel da empresa</h1>
<p>Bem-vinda, <?= e($u['nome']) ?>.</p>
<div class="info">Em construção: publicações, candidatos e pedido de selo (próximas fases).</div>
<?php require __DIR__ . '/../../src/templates/footer.php'; ?>
