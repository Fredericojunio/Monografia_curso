<?php
require __DIR__ . '/../src/bootstrap.php';
$u = utilizador_atual();

// Empresas e administradores vao para o seu painel
if ($u && $u['tipo'] !== 'jovem') {
    redirecionar(pagina_inicial($u['tipo']));
}

$titulo = 'Início';
require __DIR__ . '/../src/templates/header.php';
?>
<?php if ($u): ?>
  <h1>Olá, <?= e($u['nome']) ?></h1>
  <div class="info">Aqui vai aparecer o feed com as publicações das empresas (próxima fase).</div>
<?php else: ?>
  <h1>Sua ligação com novas oportunidades</h1>
  <p>Vagas, estágios e formações publicadas por empresas verificadas.</p>
  <p><a class="botao" href="<?= e(url('/login.php')) ?>">Entrar</a></p>
  <p class="centro">
    <a href="<?= e(url('/registo-jovem.php')) ?>">Sou jovem</a> &middot;
    <a href="<?= e(url('/registo-empresa.php')) ?>">Sou empresa</a>
  </p>
<?php endif; ?>
<?php require __DIR__ . '/../src/templates/footer.php'; ?>
