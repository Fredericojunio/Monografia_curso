<?php
// Cria um administrador (SILAS). Uso, no terminal:
//   php criar-admin.php "Nome" email@exemplo.com SenhaForte123
if (PHP_SAPI !== 'cli') {
    exit('Execute este ficheiro apenas no terminal.');
}
require __DIR__ . '/src/config.php';
require __DIR__ . '/src/db.php';

[$script, $nome, $email, $senha] = array_pad($argv, 4, null);
if (!$nome || !$email || !$senha || strlen($senha) < 8) {
    exit("Uso: php criar-admin.php \"Nome\" email senha (minimo 8 caracteres)\n");
}

db()->prepare(
    "INSERT INTO utilizador (nome, email, senha_hash, tipo, estado)
     VALUES (?, ?, ?, 'admin', 'ativo')"
)->execute([$nome, strtolower($email), password_hash($senha, PASSWORD_DEFAULT)]);

echo "Administrador criado: $email\n";
