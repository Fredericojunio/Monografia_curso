<?php
// Escapa texto para HTML (evita XSS)
function e(?string $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function url(string $caminho): string
{
    return BASE_URL . $caminho;
}

function redirecionar(string $caminho): void
{
    header('Location: ' . url($caminho));
    exit;
}

function flash(string $tipo, string $mensagem): void
{
    $_SESSION['flash'][] = ['tipo' => $tipo, 'msg' => $mensagem];
}

function obter_flash(): array
{
    $mensagens = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $mensagens;
}

// Devolve o valor enviado antes (para repor o formulario com erros)
function antigo(string $campo, string $padrao = ''): string
{
    return e($_POST[$campo] ?? $padrao);
}

function nuit_valido(string $nuit): bool
{
    return (bool) preg_match('/^\d{9}$/', $nuit);
}

function telefone_valido(string $telefone): bool
{
    return $telefone === '' || (bool) preg_match('/^\+?[0-9 ]{9,15}$/', $telefone);
}

// Verifica a tabela de bloqueios (contas banidas)
function bloqueado(string $tipo, string $valor): bool
{
    $st = db()->prepare('SELECT 1 FROM bloqueio WHERE tipo = ? AND valor = ? LIMIT 1');
    $st->execute([$tipo, $valor]);
    return (bool) $st->fetchColumn();
}

// ex.: jo***@gmail.com
function mascarar_email(string $email): string
{
    [$local, $dominio] = array_pad(explode('@', $email, 2), 2, '');
    return substr($local, 0, 2) . '***@' . $dominio;
}
