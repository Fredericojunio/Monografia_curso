<?php
// Codigos de confirmacao de e-mail

// Cria um codigo de 6 digitos, guarda o hash na BD e devolve o codigo
function gerar_codigo(int $utilizadorId): string
{
    $pdo = db();
    $pdo->prepare('UPDATE codigo_confirmacao SET usado = 1 WHERE utilizador_id = ? AND usado = 0')
        ->execute([$utilizadorId]);

    $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $minutos = (int) CODIGO_VALIDADE_MIN;

    $pdo->prepare(
        "INSERT INTO codigo_confirmacao (utilizador_id, codigo_hash, expira_em)
         VALUES (?, ?, NOW() + INTERVAL $minutos MINUTE)"
    )->execute([$utilizadorId, hash('sha256', $codigo)]);

    return $codigo;
}

// Em desenvolvimento: escreve o codigo num ficheiro (nao e enviado nem mostrado)
function enviar_codigo(string $email, string $codigo): void
{
    if (AMBIENTE === 'desenvolvimento') {
        $pasta = dirname(LOG_CODIGOS);
        if (!is_dir($pasta)) {
            mkdir($pasta, 0775, true);
        }
        $linha = date('Y-m-d H:i:s') . ' | ' . $email . ' | ' . $codigo . PHP_EOL;
        file_put_contents(LOG_CODIGOS, $linha, FILE_APPEND | LOCK_EX);
        return;
    }
    // Producao: aqui entra o envio por SMTP (por exemplo com PHPMailer)
    error_log('Envio de e-mail por SMTP ainda nao configurado.');
}

// Gera, envia e prepara a pagina de confirmacao
function iniciar_confirmacao(int $utilizadorId, string $email): void
{
    enviar_codigo($email, gerar_codigo($utilizadorId));
    $_SESSION['confirmar_id']      = $utilizadorId;
    $_SESSION['ultimo_envio']      = time();
    $_SESSION['tentativas_codigo'] = 0;
}

// Confirma o codigo; se estiver certo, ativa a conta
function verificar_codigo(int $utilizadorId, string $codigo): bool
{
    $pdo = db();
    $st = $pdo->prepare(
        'SELECT id FROM codigo_confirmacao
         WHERE utilizador_id = ? AND codigo_hash = ? AND usado = 0 AND expira_em > NOW()
         ORDER BY id DESC LIMIT 1'
    );
    $st->execute([$utilizadorId, hash('sha256', $codigo)]);
    $id = $st->fetchColumn();
    if (!$id) {
        return false;
    }
    $pdo->prepare('UPDATE codigo_confirmacao SET usado = 1 WHERE id = ?')->execute([$id]);
    $pdo->prepare("UPDATE utilizador SET estado = 'ativo' WHERE id = ? AND estado = 'pendente'")
        ->execute([$utilizadorId]);
    return true;
}
