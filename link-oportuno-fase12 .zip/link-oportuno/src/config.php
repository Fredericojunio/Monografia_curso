<?php
// ---------------------------------------------------------
// Configuracao do Link-Oportuno
// ---------------------------------------------------------

// 'desenvolvimento': o codigo de confirmacao NAO e enviado por e-mail;
// fica guardado em storage/logs/codigos.log para o passarmos manualmente.
// 'producao': o envio deve ser feito por SMTP (ainda por implementar).
define('AMBIENTE', 'desenvolvimento');

// Base de dados. Valores por defeito do XAMPP; no Codespaces vêm das
// variaveis de ambiente definidas em .devcontainer/devcontainer.json
define('DB_HOST', 'localhost');
define('DB_NAME', 'link_oportuno');
define('DB_USER', getenv('LINK_DB_USER') !== false ? getenv('LINK_DB_USER') : 'root');
define('DB_PASS', getenv('LINK_DB_PASS') !== false ? getenv('LINK_DB_PASS') : '');

// Caminho do site no navegador. No XAMPP, se a pasta estiver em
// C:\xampp\htdocs\link-oportuno\public, use '/link-oportuno/public'.
// No Codespaces o site fica na raiz, por isso a variavel vem vazia.
$base = getenv('LINK_BASE_URL');
define('BASE_URL', $base === false ? '/link-oportuno/public' : $base);

define('RAIZ', dirname(__DIR__));
define('LOG_CODIGOS', RAIZ . '/storage/logs/codigos.log');

define('CODIGO_VALIDADE_MIN', 10);   // validade do codigo (minutos)
define('REENVIO_SEGUNDOS', 60);      // espera entre reenvios
define('MAX_TENTATIVAS', 5);         // tentativas de codigo / login
