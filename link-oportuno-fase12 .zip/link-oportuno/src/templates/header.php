<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($titulo ?? 'Link-Oportuno') ?> | Link-Oportuno</title>
  <link rel="stylesheet" href="<?= e(url('/css/estilo.css')) ?>">
</head>
<body>
<header class="topo">
  <a class="marca" href="<?= e(url('/index.php')) ?>">Link<span>-</span>Oportuno</a>
  <?php if ($u = utilizador_atual()): ?>
    <a class="sair" href="<?= e(url('/logout.php')) ?>">Sair</a>
  <?php endif; ?>
</header>
<main class="conteudo">
<?php foreach (obter_flash() as $f): ?>
  <div class="aviso aviso-<?= e($f['tipo']) ?>"><?= e($f['msg']) ?></div>
<?php endforeach; ?>
