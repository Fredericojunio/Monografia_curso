<?php
// Sessao e controlo de acesso por perfil
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function utilizador_atual(): ?array
{
    if (empty($_SESSION['uid'])) {
        return null;
    }
    return [
        'id'   => (int) $_SESSION['uid'],
        'tipo' => $_SESSION['tipo'],
        'nome' => $_SESSION['nome'],
    ];
}

function entrar(array $utilizador): void
{
    session_regenerate_id(true);
    $_SESSION['uid']  = (int) $utilizador['id'];
    $_SESSION['tipo'] = $utilizador['tipo'];
    $_SESSION['nome'] = $utilizador['nome'];
    unset($_SESSION['confirmar_id'], $_SESSION['tentativas_codigo'], $_SESSION['tentativas_login']);
}

function sair(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function exigir_login(): array
{
    $u = utilizador_atual();
    if ($u === null) {
        redirecionar('/login.php');
    }
    return $u;
}

function exigir_perfil(string $tipo): array
{
    $u = exigir_login();
    if ($u['tipo'] !== $tipo) {
        http_response_code(403);
        exit('Acesso negado.');
    }
    return $u;
}

function pagina_inicial(string $tipo): string
{
    switch ($tipo) {
        case 'empresa': return '/empresa/painel.php';
        case 'admin':   return '/admin/index.php';
        default:        return '/index.php';
    }
}
