-- =====================================================
-- Link-Oportuno: base de dados (MySQL 8+)
-- Plataforma que liga jovens a vagas, estagios e formacao
-- =====================================================

CREATE DATABASE IF NOT EXISTS link_oportuno
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE link_oportuno;

-- -----------------------------------------------------
-- Tabelas de apoio
-- -----------------------------------------------------
CREATE TABLE provincia (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE area_atuacao (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO provincia (nome) VALUES
  ('Maputo Cidade'), ('Maputo Provincia'), ('Gaza'), ('Inhambane'),
  ('Sofala'), ('Manica'), ('Tete'), ('Zambezia'),
  ('Nampula'), ('Cabo Delgado'), ('Niassa');

INSERT INTO area_atuacao (nome) VALUES
  ('Tecnologia'), ('Educacao'), ('Saude'), ('Agricultura'),
  ('Comercio'), ('Construcao'), ('Transportes'), ('Financas'),
  ('Turismo'), ('Outras');

-- -----------------------------------------------------
-- Utilizadores
-- -----------------------------------------------------
CREATE TABLE utilizador (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(120) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  telefone   VARCHAR(20),
  senha_hash VARCHAR(255) NOT NULL,
  tipo       ENUM('jovem','empresa','admin') NOT NULL,
  estado     ENUM('pendente','ativo','suspenso','banido') NOT NULL DEFAULT 'pendente',
  criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE jovem (
  utilizador_id INT PRIMARY KEY,
  provincia_id  INT,
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE CASCADE,
  FOREIGN KEY (provincia_id)  REFERENCES provincia(id)
) ENGINE=InnoDB;

CREATE TABLE empresa (
  utilizador_id INT PRIMARY KEY,
  nome          VARCHAR(150) NOT NULL,
  nuit          CHAR(9) NOT NULL UNIQUE,
  provincia_id  INT,
  area_id       INT,
  descricao     TEXT,
  foto_perfil   VARCHAR(255),
  imagem_capa   VARCHAR(255),
  estado_selo   ENUM('sem_pedido','em_analise','verificada','recusada')
                NOT NULL DEFAULT 'sem_pedido',
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE CASCADE,
  FOREIGN KEY (provincia_id)  REFERENCES provincia(id),
  FOREIGN KEY (area_id)       REFERENCES area_atuacao(id)
) ENGINE=InnoDB;

CREATE TABLE codigo_confirmacao (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  utilizador_id INT NOT NULL,
  codigo_hash   CHAR(64) NOT NULL,
  expira_em     DATETIME NOT NULL,
  usado         BOOLEAN NOT NULL DEFAULT 0,
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Publicacoes e interacao
-- -----------------------------------------------------
CREATE TABLE publicacao (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  empresa_id   INT NOT NULL,
  tipo         ENUM('vaga','estagio','formacao') NOT NULL,
  titulo       VARCHAR(150) NOT NULL,
  descricao    TEXT NOT NULL,
  imagem       VARCHAR(255),
  provincia_id INT,
  area_id      INT,
  prazo        DATE,
  estado       ENUM('ativa','encerrada','oculta','removida') NOT NULL DEFAULT 'ativa',
  criado_em    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (empresa_id)   REFERENCES empresa(utilizador_id) ON DELETE CASCADE,
  FOREIGN KEY (provincia_id) REFERENCES provincia(id),
  FOREIGN KEY (area_id)      REFERENCES area_atuacao(id),
  INDEX idx_pub_estado (estado, criado_em)
) ENGINE=InnoDB;

CREATE TABLE comentario (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  publicacao_id INT NOT NULL,
  jovem_id      INT NOT NULL,
  texto         VARCHAR(500) NOT NULL,
  estado        ENUM('visivel','removido') NOT NULL DEFAULT 'visivel',
  criado_em     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (publicacao_id) REFERENCES publicacao(id) ON DELETE CASCADE,
  FOREIGN KEY (jovem_id)      REFERENCES jovem(utilizador_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE seguidor (
  jovem_id   INT NOT NULL,
  empresa_id INT NOT NULL,
  data       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (jovem_id, empresa_id),
  FOREIGN KEY (jovem_id)   REFERENCES jovem(utilizador_id)   ON DELETE CASCADE,
  FOREIGN KEY (empresa_id) REFERENCES empresa(utilizador_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Candidaturas e documentos
-- (os documentos so sao vistos pela empresa da publicacao
--  e apenas os escolhidos em candidatura_documento)
-- -----------------------------------------------------
CREATE TABLE documento (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  jovem_id  INT NOT NULL,
  nome      VARCHAR(150) NOT NULL,
  tipo      VARCHAR(50),
  caminho   VARCHAR(255) NOT NULL,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (jovem_id) REFERENCES jovem(utilizador_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE candidatura (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  jovem_id         INT NOT NULL,
  publicacao_id    INT NOT NULL,
  estado           ENUM('enviada','vista') NOT NULL DEFAULT 'enviada',
  partilha_email    BOOLEAN NOT NULL DEFAULT 0,
  partilha_telefone BOOLEAN NOT NULL DEFAULT 0,
  partilha_whatsapp BOOLEAN NOT NULL DEFAULT 0,
  criado_em        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_candidatura (jovem_id, publicacao_id),
  FOREIGN KEY (jovem_id)      REFERENCES jovem(utilizador_id) ON DELETE CASCADE,
  FOREIGN KEY (publicacao_id) REFERENCES publicacao(id)       ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE candidatura_documento (
  candidatura_id INT NOT NULL,
  documento_id   INT NOT NULL,
  PRIMARY KEY (candidatura_id, documento_id),
  FOREIGN KEY (candidatura_id) REFERENCES candidatura(id) ON DELETE CASCADE,
  FOREIGN KEY (documento_id)   REFERENCES documento(id)   ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Verificacao e administracao (SILAS)
-- -----------------------------------------------------
CREATE TABLE verificacao (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  empresa_id    INT NOT NULL,
  documento     VARCHAR(255) NOT NULL,
  estado        ENUM('em_analise','aprovada','recusada') NOT NULL DEFAULT 'em_analise',
  motivo_recusa VARCHAR(255),
  admin_id      INT,
  decidido_em   DATETIME,
  criado_em     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (empresa_id) REFERENCES empresa(utilizador_id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id)   REFERENCES utilizador(id)
) ENGINE=InnoDB;

CREATE TABLE denuncia (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  denunciante_id INT NOT NULL,
  alvo_tipo      ENUM('publicacao','comentario','empresa') NOT NULL,
  alvo_id        INT NOT NULL,
  motivo         VARCHAR(255) NOT NULL,
  estado         ENUM('aberta','em_analise','resolvida','arquivada') NOT NULL DEFAULT 'aberta',
  criado_em      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (denunciante_id) REFERENCES utilizador(id),
  INDEX idx_denuncia_alvo (alvo_tipo, alvo_id)
) ENGINE=InnoDB;

CREATE TABLE medida_admin (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT NOT NULL,
  empresa_id  INT NOT NULL,
  tipo        ENUM('aviso','remocao','retirada_selo','suspensao','banimento') NOT NULL,
  motivo      VARCHAR(255) NOT NULL,
  prazo_ate   DATE,
  denuncia_id INT,
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id)    REFERENCES utilizador(id),
  FOREIGN KEY (empresa_id)  REFERENCES empresa(utilizador_id),
  FOREIGN KEY (denuncia_id) REFERENCES denuncia(id)
) ENGINE=InnoDB;

CREATE TABLE recurso (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  medida_id  INT NOT NULL,
  empresa_id INT NOT NULL,
  texto      TEXT NOT NULL,
  resposta   TEXT,
  estado     ENUM('pendente','aceite','rejeitado') NOT NULL DEFAULT 'pendente',
  criado_em  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (medida_id)  REFERENCES medida_admin(id),
  FOREIGN KEY (empresa_id) REFERENCES empresa(utilizador_id)
) ENGINE=InnoDB;

-- Impede novo registo de NUIT ou e-mail depois de um banimento
CREATE TABLE bloqueio (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  tipo      ENUM('nuit','email') NOT NULL,
  valor     VARCHAR(150) NOT NULL,
  medida_id INT NOT NULL,
  UNIQUE KEY uq_bloqueio (tipo, valor),
  FOREIGN KEY (medida_id) REFERENCES medida_admin(id)
) ENGINE=InnoDB;

CREATE TABLE notificacao (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  utilizador_id INT NOT NULL,
  texto         VARCHAR(255) NOT NULL,
  lida          BOOLEAN NOT NULL DEFAULT 0,
  criado_em     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE CASCADE
) ENGINE=InnoDB;
